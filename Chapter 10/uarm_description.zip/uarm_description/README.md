# Testing Model View

Test the robot description:

    roslaunch uarm_description view_model.launch

